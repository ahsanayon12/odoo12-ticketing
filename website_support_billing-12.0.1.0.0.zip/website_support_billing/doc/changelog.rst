v1.0.0
======
* Port to version 12